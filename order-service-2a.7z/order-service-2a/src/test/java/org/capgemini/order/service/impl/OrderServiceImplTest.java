
package org.capgemini.order.service.impl;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.capgemini.common.DataAccessException;
import org.capgemini.common.ServiceException;
import org.capgemini.order.dao.OrderDao;
import org.capgemini.order.model.domain.OrderSummary;
import org.capgemini.order.model.entity.OrderEntity;
import org.capgemini.order.model.entity.OrderItemEntity;
import org.capgemini.order.model.transformer.OrderEntityToOrderSummaryTransformer;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class OrderServiceImplTest {
	
	private OrderItemEntity orderItemEntity;
	private OrderServiceImpl target;
	private OrderEntity orderEntity;
	private OrderItemEntity orderItemEntity2;
	private List<OrderItemEntity> orderItemList;
	
	private List<OrderEntity> orderEntityList;
	private OrderEntityToOrderSummaryTransformer transformer;
	
	
	@Mock
	private OrderDao orderDao;

	@Before
	public void setUp() throws Exception {
		target=new OrderServiceImpl();
		transformer = new OrderEntityToOrderSummaryTransformer();
		target.setOrderDao(orderDao);
		target.setTransformer(transformer);
		
		orderItemEntity = new OrderItemEntity();
		orderItemEntity.setId(01);
		orderItemEntity.setQuantity(10);
		BigDecimal price = new BigDecimal(20); //200
		orderItemEntity.setSellingPrice(price);
		orderItemEntity.setSku("Sku123");
		Date date = new Date(21021994);
		orderItemEntity.setAddedToOrderDateTime(date);
		orderItemEntity.setOwningOrder(orderEntity);


		orderItemEntity2 = new OrderItemEntity();
		orderItemEntity2.setId(22);
		orderItemEntity2.setQuantity(10);
		BigDecimal price1 = new BigDecimal(10);
		orderItemEntity2.setSellingPrice(price1);//100
		orderItemEntity2.setSku("Sku33");
		Date date2 = new Date(21021994);
		orderItemEntity2.setAddedToOrderDateTime(date2);
		orderItemEntity2.setOwningOrder(orderEntity);

		orderItemList = new LinkedList<>();
		orderItemList.add(orderItemEntity);
		orderItemList.add(orderItemEntity2);


		orderEntity = new OrderEntity();
		orderEntity.setId(11);
		orderEntity.setBillingAddressId(1234576);
		Date completionDate = new Date(19092004);
		orderEntity.setCompletionDate(completionDate );
		orderEntity.setCustomerId(321);
		orderEntity.setOrderLabel("orderNo.1");
		orderEntity.setOrderNumber("5343");
		orderEntity.setShippingAddressId(43224324);
		orderEntity.setOrderItemList(orderItemList);
		
		orderEntityList = new LinkedList<>();
		orderEntityList.add(orderEntity);
			
	}

	@After
	public void tearDown() throws Exception {
		target=null;
		transformer=null;
		orderItemEntity=null;
		orderItemEntity2=null;
		orderItemList=null;
		orderEntity=null;
	}

	@Test
	public void getOrderSummaryShouldReturnOrderSummaryResult() throws ServiceException, DataAccessException {
		when(orderDao.findOrdersByCustomer(321)).thenReturn(orderEntityList);
		List<OrderSummary> result=target.getOrderSummary(321);
		assertEquals("5343",result.get(0).getOrderNumber());
		assertEquals(20,result.get(0).getItemCount());
		//assertEquals("suppose to get 300",new BigDecimal(300),result.get(0).getTotalAmount());
	}
	
	@Test(expected=ServiceException.class)
	public void getOrderSummaryShouldThrowServiceException() throws DataAccessException, ServiceException {
		when(orderDao.findOrdersByCustomer(321)).thenThrow(DataAccessException.class);
		target.getOrderSummary(321);

	}

}
