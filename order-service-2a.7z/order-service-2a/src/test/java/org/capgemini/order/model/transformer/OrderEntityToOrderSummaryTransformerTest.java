package org.capgemini.order.model.transformer;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;






import org.capgemini.order.model.domain.OrderSummary;
import org.capgemini.order.model.entity.OrderEntity;
import org.capgemini.order.model.entity.OrderItemEntity;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class OrderEntityToOrderSummaryTransformerTest {
	private OrderItemEntity orderItemEntity;
	private OrderEntityToOrderSummaryTransformer target;
	private OrderEntity orderEntity;
	private OrderItemEntity orderItemEntity2;
	List<OrderItemEntity> orderItemList;

	@Before
	public void setUp() throws Exception {
		target = new OrderEntityToOrderSummaryTransformer();

		orderItemEntity = new OrderItemEntity();
		orderItemEntity.setId(01);
		orderItemEntity.setQuantity(10);
		BigDecimal price = new BigDecimal(20); //546
		orderItemEntity.setSellingPrice(price);
		orderItemEntity.setSku("Sku123");
		Date date = new Date(21021994);
		orderItemEntity.setAddedToOrderDateTime(date);
		orderItemEntity.setOwningOrder(orderEntity);
		


		orderItemEntity2 = new OrderItemEntity();
		orderItemEntity2.setId(22);
		orderItemEntity2.setQuantity(10);
		BigDecimal price1 = new BigDecimal(10);// 100
		orderItemEntity2.setSellingPrice(price1);
		orderItemEntity2.setSku("Sku33");
		Date date2 = new Date(21021994);
		orderItemEntity2.setAddedToOrderDateTime(date2);
		orderItemEntity2.setOwningOrder(orderEntity);

		orderItemList = new LinkedList<>();
		orderItemList.add(orderItemEntity);
		orderItemList.add(orderItemEntity2);


		orderEntity = new OrderEntity();
		orderEntity.setId(11);
		orderEntity.setBillingAddressId(1234576);
		Date completionDate = new Date(19092004);
		orderEntity.setCompletionDate(completionDate );
		orderEntity.setCustomerId(321);
		orderEntity.setOrderLabel("orderNo.1");
		orderEntity.setOrderNumber("5343");
		orderEntity.setShippingAddressId(43224324);
		orderEntity.setOrderItemList(orderItemList);
	}

	@After
	public void tearDown() throws Exception {
		target = null;
		orderEntity = null;
		orderItemEntity = null;
		orderItemEntity2 = null;
	}

	@Test
	public void testOrderEntityToOrderSummaryTransformerShouldReturnOrderSummary() {
		OrderSummary result = target.transform(orderEntity);
		assertNotNull("Result is expected not null",result);
		assertEquals(20, result.getItemCount());
		assertEquals("5343", result.getOrderNumber());
		//assertEquals("suo get300""300", result.getTotalAmount());
	
	}

	@Test(expected=IllegalArgumentException.class)
	public void transformShouldThrowIllegalArgumentException() {
		OrderSummary result=target.transform(null);
	}	

}
