package org.capgemini.order.service;

import java.util.List;

import org.capgemini.common.ServiceException;
import org.capgemini.order.model.domain.OrderSummary;


public interface OrderService {

	List<OrderSummary> getOrderSummary(long customerId) throws ServiceException;
}
