package org.capgemini.order.dao;

import java.util.List;

import org.capgemini.common.DataAccessException;
import org.capgemini.order.model.entity.OrderEntity;



public interface OrderDao {

	OrderEntity findById(long id) throws DataAccessException;
	int insert(OrderEntity order) throws DataAccessException;
	
	List<OrderEntity> findOrdersByCustomer(long customerId) throws DataAccessException;
}